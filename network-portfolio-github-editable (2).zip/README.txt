GitHub Pages 업로드 방법

1. 저장소에 index.html 파일과 assets 폴더를 함께 업로드합니다.
2. GitHub 저장소 > Settings > Pages 로 이동합니다.
3. Deploy from a branch / main / root 를 선택합니다.
4. 생성된 Pages URL을 제출하면 됩니다.

문장 수정:
- GitHub에서 index.html을 클릭
- 연필(Edit) 아이콘 클릭
- 수정할 문장을 검색해서 텍스트만 변경
- Commit changes

중요:
- assets 폴더 이름과 이미지 파일명은 바꾸지 않는 것이 가장 쉽습니다.
- HTML의 각 페이지 시작 부분에 주석이 있어 수정 위치를 찾기 쉽습니다.
